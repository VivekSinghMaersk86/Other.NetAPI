using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMS.Core.Dto
{
    public class UpdateDockRequestDto
    {
        public Guid AppointmentId { get; set; }
        public Guid? WarehouseId { get; set; }
        public Guid? DockDoorId { get; set; }
        public Guid userId { get; set; }

    }
}