﻿using FluentValidation;
using GMS.Core.Dto;

 namespace GMS.API.Validators
 {
 
    public class UpdateRequestDockValidator : AbstractValidator<UpdateDockRequestDto>
    {
        public UpdateRequestDockValidator()
        {
            RuleFor(m => m.AppointmentId).NotNull();
            RuleFor(m => m.WarehouseId).NotNull();
            RuleFor(m => m.DockDoorId).NotNull();

        }
    }
}
