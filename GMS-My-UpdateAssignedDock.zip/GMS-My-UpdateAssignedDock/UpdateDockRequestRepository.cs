using AutoMapper;
using GMS.Core.Dto;
using GMS.Core.Interfaces.Repositories;
using GMS.Domain.Context;
using GMS.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GMS.Infrastructure.Repositories
{
     public class UpdateDockRequestRepository : Repository<TDockDoorAppointment>, IUpdateDockRequestRepository
      {
        public UpdateDockRequestRepository(gms_dbContext context) : base(context)
        {

        }

    }
}
