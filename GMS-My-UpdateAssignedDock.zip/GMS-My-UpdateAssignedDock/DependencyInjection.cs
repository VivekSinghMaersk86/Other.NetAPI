﻿using GMS.Core.Interfaces.Repositories;
using GMS.Core.Interfaces.Services;
using GMS.Core.Services;
using GMS.Domain.Context;
using GMS.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;

namespace GMS.API
{
    ///<Summary>
    /// DependencyInjection
    ///</Summary>
    public static class DependencyInjection
    {
        ///<Summary>
        /// ConfigureDependencyInjection
        ///</Summary>
        public static IServiceCollection ConfigureDependencyInjection(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }
            if (configuration == null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }
            string connectionstring = Environment.GetEnvironmentVariable("ConnectionString");          
            services.AddDbContext<gms_dbContext>(options => options.UseSqlServer(connectionstring));
            services.AddTransient<IInspectionService, InspectionService>();
            services.AddTransient<IInspectionRepository, InspectionRepository>();
            services.AddTransient<IUpdateRequestDockService, UpdateRequestDockService>();
            services.AddTransient<IUpdateDockRequestRepository, InspectionRepository>();
            return services;
        }
    }
}
