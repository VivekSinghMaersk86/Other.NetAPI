using GMS.Core.Dto;
using GMS.Domain.Entities;

namespace GMS.Core.Interfaces.Repositories
{
     public interface IUpdateDockRequestRepository : IRepository<TDockDoorAppointment>
    {
        
    }
}
