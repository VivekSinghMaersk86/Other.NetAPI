﻿using AutoMapper;
using GMS.Domain.Entities;
using static GMS.Core.Helper.Constants;

namespace GMS.API.Helper
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
             CreateMap<Core.Dto.InspectionRequestDto, TInGateInspection>()
                .ForPath(dest => dest.AppointmentId, opt => opt.MapFrom(src => src.AppointmentId))
                .ForPath(dest => dest.SealCheck, opt => opt.MapFrom(src => src.SealCheck))
                .ForPath(dest => dest.SealCheckComments, opt => opt.MapFrom(src => src.SealCheckComments))
                .ForPath(dest => dest.LpnCheck, opt => opt.MapFrom(src => src.LpnCheck))
                .ForPath(dest => dest.LpnCheckComments, opt => opt.MapFrom(src => src.LpnCheckComments))
                .ForPath(dest => dest.DamageCheck, opt => opt.MapFrom(src => src.DamageCheck))
                .ForPath(dest => dest.DamageCheckComments, opt => opt.MapFrom(src => src.DamageCheckComments))
                .ForPath(dest => dest.FacilityId, opt => opt.MapFrom(src => src.FacilityId))
                .ForPath(dest => dest.RowId, opt => opt.MapFrom(src => Guid.NewGuid()))
                .ForPath(dest => dest.InspectionStatus, opt => opt.MapFrom(src => (int)Enum.Parse(typeof(InspectionStatus), src.InspectionStatus)))
                .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.InspectedByUserId))
                .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.InspectedByUserId))
                .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
                .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<Core.Dto.UpdateDockRequestDto, TDockDoorAppointment>()
             //.ForPath(dest => dest.AppointmentId, opt => opt.MapFrom(src => src.AppointmentId))
             //.ForPath(dest => dest.WarehouseId, opt => opt.MapFrom(src => src.WarehouseId))
             //.ForPath(dest => dest.DockDoorId, opt => opt.MapFrom(src => src.DockDoorId));
               .ForPath(dest => dest.Id, opt => opt.MapFrom(src => src.userId));   


        }

    }
}
 