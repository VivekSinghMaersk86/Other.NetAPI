﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GMS.Core.Dto;

namespace GMS.Core.Interfaces.Services
{
    public interface IUpdateRequestDockService
    {
       Task<ResponseStatus> UpdateAssignDock(UpdateDockRequestDto updateDockRequestDto);
    }
}
