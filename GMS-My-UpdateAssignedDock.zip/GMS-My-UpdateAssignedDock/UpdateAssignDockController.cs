using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using GMS.Core.Interfaces.Services;
using GMS.Core.Dto;
using GMS.API.Validators;
using System.Net;

namespace GMS.API.Controllers
{
    /// UpdateAssignedDockController
   
    [Route("api/[controller]")]
    [ApiController]
    public class UpdateAssignedDockController : ControllerBase
    {
        private readonly IUpdateRequestDockService _updateRequestDockService;
        private readonly ILogger<UpdateAssignedDockController> _logger;

        ///<Summary>
        /// UpdateAssignedDockControllerConstructor
        ///</Summary>
        public UpdateAssignedDockController(IUpdateRequestDockService updateRequestDockService, ILogger<UpdateAssignedDockController> logger)
        {
            _updateRequestDockService = updateRequestDockService ?? throw new ArgumentNullException(nameof(updateRequestDockService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        ///<Summary>
        /// Update Assign Dock data
        ///</Summary>
        [HttpPost]
        [Route("UpdateAssignDock")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public async Task<IActionResult> UpdateAssignDock([FromBody] UpdateDockRequestDto updateDockRequestDto)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - UpdateRequestDock");
                var validator = new UpdateRequestDockValidator();

                var validationResult = validator.Validate(updateDockRequestDto);
                if (validationResult.IsValid)
                {
                    var result = await _updateRequestDockService.UpdateAssignDock(updateDockRequestDto);
                    return Ok(result);
                }
                else
                    return BadRequest(validationResult.Errors);

            }
            catch (Exception ex)
            {
                _logger.LogError("UpdateRequestDock Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }
        }

    }
}