﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GMS.Core.Interfaces.Repositories;
using GMS.Core.Interfaces.Services;
using GMS.Core.Dto;
using Microsoft.Extensions.Logging;
using AutoMapper;
using GMS.Domain.Entities;

namespace GMS.Core.Services
{
     public class UpdateRequestDockService : IUpdateRequestDockService
        {
        public readonly IUpdateDockRequestRepository _updateDockRequestRepository;
        private readonly ILogger<UpdateRequestDockService> _logger;
        private readonly IMapper _mapper;
        public UpdateRequestDockService(IUpdateDockRequestRepository updateDockRequestRepository, ILogger<IUpdateRequestDockService> logger, IMapper mapper)
        {
            _logger = (ILogger<UpdateRequestDockService>)(logger ?? throw new ArgumentNullException(nameof(logger)));
            _updateDockRequestRepository = updateDockRequestRepository;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(_mapper));
        }

        public async Task<ResponseStatus> UpdateAssignDock(UpdateDockRequestDto updateDockRequestDto)
        {
            _logger.LogInformation("Service Method : UpdateRequestDockServicen/UpdateAssignDock - Start");
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                 var AddDock = _mapper.Map<UpdateDockRequestDto, TDockDoorAppointment>(updateDockRequestDto);
                 await _updateDockRequestRepository.AddAsync(AddDock);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : UpdateRequestDockServicen/UpdateAssignDock Error - " + ex);
            }
            return responseStatus;
        }


    }
}
