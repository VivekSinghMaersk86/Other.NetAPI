﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YMS.Core.Helper
{
    public class Constants
    {
        public enum MovementStatus
        {
            Create = 1,
            Accept,
            Complete,
            Reject
        }
        public enum Priority
        {
            High = 1,
            Medium,
            Low,
        }
    }
}
