﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Domain.Entities;

namespace YMS.Core.Dto.ResponseDto
{
    public class PendingYardMovementResponseDto
    {
        public Guid MovementId { get; set; }

        public int YardMovementNumber { get; set; }

        public String Source { get; set; }

        public String Destination { get; set; }

        public DateTime? Created { get; set; }

        public string EqupmentNumber { get; set; } = null!;

        public string EqupmentType { get; set; } = null!;

        public string MoveType { get; set; }

        public string TrailerNumber { get; set; } = null!;

        public string Periority { get; set; }

    }
}