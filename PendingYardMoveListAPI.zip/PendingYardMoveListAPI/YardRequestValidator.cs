﻿using FluentValidation;
using YMS.Core.Dto.RequestDto;

namespace YMS.API.Validators
{
    public class YardRequestValidator : AbstractValidator<CreateYardRequestDto>
    {
        public YardRequestValidator()
        {
            RuleFor(m => m.YardName).NotEmpty().WithMessage("Yard number is Mandatory");
            RuleFor(m => m.YardDescription).NotEmpty().WithMessage("Yard Description is Mandatory");
            RuleFor(m => m.YardOrganization).NotEmpty().WithMessage("Yard Organization is Mandatory");
        }
    }
}
