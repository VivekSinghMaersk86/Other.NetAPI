﻿using YMS.Core.Interfaces.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;
using YMS.API.Validators;

namespace YMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class YardController : Controller
    {

        private readonly IYardService _yardService;
        private readonly ILogger<YardController> _logger;

        public YardController(IYardService yardService, ILogger<YardController> logger)
        {
            _yardService = yardService ?? throw new ArgumentNullException(nameof(yardService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        //<summary>
        /// CreateYard .
        ///</summary>
        ///<returns>Status and Status Code</returns>
        ///<remarks>
        /// Tables used.->MYard
        ///</remarks>
        [HttpPost]
        [Route("CreateYard")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public async Task<IActionResult> CreateYard(CreateYardRequestDto yardRequestDto)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - CreateYard");

                var validator = new YardRequestValidator();
                var validationResult = validator.Validate(yardRequestDto);
                if (validationResult.IsValid)
                {
                    var result = await _yardService.CreateYard(yardRequestDto);
                    return Ok(result);
                }
                else
                    return BadRequest(validationResult.Errors);
            }
            catch (Exception ex)
            {
                _logger.LogError("CreateYard Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }
        }

        //<summary>
        /// Delete Yard.
        ///</summary>
        ///<returns>Status and Status Code</returns>
        ///<remarks>
        /// Tables used.->MYard
        ///</remarks>
        ///
        [Route("DeleteYard")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult> DeleteYard([FromBody] Guid yardId)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - DeleteYard");
                var result = await _yardService.DeleteYard(yardId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("DeleteYard Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }
        }

        //<summary>
        /// UpdateYard .
        ///</summary>
        ///<returns>Status and Status Code</returns>
        ///<remarks>
        /// Tables used.->MYard
        ///</remarks>
        [HttpPost]
        [Route("UpdateYard")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult> UpdateYard(UpdateYardRequestDto yardRequestDto)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - UpdateYard");
                var result = await _yardService.UpdateYard(yardRequestDto);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("UpdateYard Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }
        }

        [Route("UpdateAssignedYard")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdateAssignedYard(UpdateAssignedYardRequestDto updateAssignedYard)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - UpdateAssignedYard");
                var result = await _yardService.UpdateAssignedYard(updateAssignedYard);
                return Ok(result);

            }
            catch (Exception ex)
            {
                _logger.LogError("UpdateAssignedYard Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }

        }

        //<summary>
        /// Get Available Yards.
        ///</summary>
        ///<returns>Available yards list</returns>
        ///<remarks>
        /// Tables used.->MYard
        ///</remarks>
        ///
        [Route("GetAvailableYards")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<AvailableYardsResponseDto>>> GetAvailableYards()
        {
            try
            {
                _logger.LogInformation("Start - GetAvailableYards");
                var result = await _yardService.GetAvailableYards();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetAvailableYards Error : " + ex);
                return NoContent(); ;
            }
        }

        [Route("GetListPendingYardMovements")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<IEnumerable<PendingYardMovementResponseDto>>> GetListofPendingYardMovements()
        {
            try
            {
                _logger.LogInformation("Start - GetListofPendingYardMovements");
                 var result = await _yardService.GetListofPendingYardMovements();

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError("GetListofPendingYardMovements Error : " + ex);
                return NoContent(); ;
            }
        }

    }
}
