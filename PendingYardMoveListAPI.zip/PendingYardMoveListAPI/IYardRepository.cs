﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Dto;
using YMS.Core.Dto.ResponseDto;
using YMS.Domain.Entities;

namespace YMS.Core.Interfaces.Repositories
{
   public interface IYardRepository : IRepository<MYard>
    {
        //Task<ReturnValues> SaveYard(Guid FacilityId,string YardName,string YardOrganization, string YardDescription, Guid UserId, int OperationId);
        //Task<ReturnValues> DeleteYard(int YardId, Guid UserId);
        //Task<Yard> GetYardByID(int YardId);

         Task<List<PendingYardMovementResponseDto>> GetListofPendingYardMovements();

        //Task<IEnumerable<Yard>> GetAllYard();




    }
}
