﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;

namespace YMS.Core.Interfaces.Services
{
    public interface IYardService
    {
        Task<CreateEntitytResponseDto> CreateYard(CreateYardRequestDto yardRequestDto);
        Task<ResponseStatus> DeleteYard(Guid yardId);
        Task<ResponseStatus> UpdateYard(UpdateYardRequestDto yardRequestDto);
        Task<ResponseStatus> UpdateAssignedYard(UpdateAssignedYardRequestDto yardRequestDto);
        Task<IEnumerable<AvailableYardsResponseDto>> GetAvailableYards();
        Task<IEnumerable<PendingYardMovementResponseDto>> GetListofPendingYardMovements();
    }

}
