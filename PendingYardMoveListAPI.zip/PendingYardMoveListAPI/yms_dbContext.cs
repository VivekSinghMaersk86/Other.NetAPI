﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using YMS.Domain.Entities;

namespace YMS.Domain.Context
{
    public partial class yms_dbContext : DbContext
    {
        public yms_dbContext()
        {
        }

       public yms_dbContext(DbContextOptions<yms_dbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<MCategoryType> MCategoryTypes { get; set; } = null!;
        public virtual DbSet<MDockdoor> MDockdoors { get; set; } = null!;
        public virtual DbSet<MEquipment> MEquipments { get; set; } = null!;
        public virtual DbSet<MEquipmentCategory> MEquipmentCategories { get; set; } = null!;
        public virtual DbSet<MEquipmentStatus> MEquipmentStatuses { get; set; } = null!;
        public virtual DbSet<MMoveType> MMoveTypes { get; set; } = null!;
        public virtual DbSet<MSpot> MSpots { get; set; } = null!;
        public virtual DbSet<MWarehouse> MWarehouses { get; set; } = null!;
        public virtual DbSet<MYard> MYards { get; set; } = null!;
        public virtual DbSet<MZone> MZones { get; set; } = null!;
        public virtual DbSet<MZoneType> MZoneTypes { get; set; } = null!;
        public virtual DbSet<TDockDoorAppointment> TDockDoorAppointments { get; set; } = null!;
        public virtual DbSet<TYardAppointment> TYardAppointments { get; set; } = null!;
        public virtual DbSet<TYardMovement> TYardMovements { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MCategoryType>(entity =>
            {
                entity.ToTable("m_CategoryType", "yms");

                entity.HasIndex(e => e.RowId, "m_CategoryType_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.CategoryType)
                    .HasMaxLength(150)
                    .HasColumnName("category_type");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");
            });

            modelBuilder.Entity<MDockdoor>(entity =>
            {
                entity.HasKey(e => e.DockdoorId)
                    .HasName("m_Dockdoor_pk");

                entity.ToTable("m_Dockdoor", "yms");

                entity.HasIndex(e => e.RowId, "m_Dockdoor_uc")
                    .IsUnique();

                entity.Property(e => e.DockdoorId).HasColumnName("dockdoor_id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .HasDefaultValueSql("((1))")
                    .IsFixedLength();

                entity.Property(e => e.DockdoorDescription)
                    .HasMaxLength(100)
                    .HasColumnName("dockdoor_description");

                entity.Property(e => e.DockdoorNumber)
                    .HasMaxLength(50)
                    .HasColumnName("dockdoor_number");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId).HasColumnName("row_id");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YmsWarehouseId).HasColumnName("yms_warehouse_id");

                entity.HasOne(d => d.YmsWarehouse)
                    .WithMany(p => p.MDockdoors)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.YmsWarehouseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_warehouse_id_fk");
            });

            modelBuilder.Entity<MEquipment>(entity =>
            {
                entity.ToTable("m_Equipment", "yms");

                entity.HasIndex(e => e.RowId, "m_Equipment_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.CategoryTypeId).HasColumnName("categoryType_Id");

                entity.Property(e => e.EqpCategoryId).HasColumnName("eqp_Category_Id");

                entity.Property(e => e.EqpStatusId).HasColumnName("eqp_Status_Id");

                entity.Property(e => e.EquipmentDescription).HasColumnName("equipment_Description");

                entity.Property(e => e.EquipmentName)
                    .HasMaxLength(300)
                    .HasColumnName("equipment_Name");

                entity.Property(e => e.EquipmentNumber)
                    .HasMaxLength(300)
                    .HasColumnName("equipment_Number");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YardId).HasColumnName("yard_id");

                entity.HasOne(d => d.CategoryType)
                    .WithMany(p => p.MEquipments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.CategoryTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_categoryType_id_fk");

                entity.HasOne(d => d.EqpCategory)
                    .WithMany(p => p.MEquipments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.EqpCategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_eqpcategory_fk");

                entity.HasOne(d => d.EqpStatus)
                    .WithMany(p => p.MEquipments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.EqpStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_eqpStatus_fk");
            });

            modelBuilder.Entity<MEquipmentCategory>(entity =>
            {
                entity.ToTable("m_EquipmentCategory", "yms");

                entity.HasIndex(e => e.RowId, "m_EquipmentCategory_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.EquipmentCategory)
                    .HasMaxLength(150)
                    .HasColumnName("equipment_Category");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");
            });

            modelBuilder.Entity<MEquipmentStatus>(entity =>
            {
                entity.ToTable("m_EquipmentStatus", "yms");

                entity.HasIndex(e => e.RowId, "m_EquipmentStatus_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.EquipmentStatus)
                    .HasMaxLength(150)
                    .HasColumnName("equipment_Status");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");
            });

            modelBuilder.Entity<MMoveType>(entity =>
            {
                entity.ToTable("m_MoveType", "yms");

                entity.HasIndex(e => e.RowId, "m_MoveType_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.MoveType)
                    .HasMaxLength(50)
                    .HasColumnName("moveType");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");
            });

            modelBuilder.Entity<MSpot>(entity =>
            {
                entity.ToTable("m_spot", "yms");

                entity.HasIndex(e => e.RowId, "m_spot_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.SpotNumber).HasMaxLength(150);

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YmsZoneId).HasColumnName("yms_zone_ID");

                entity.HasOne(d => d.YmsZone)
                    .WithMany(p => p.MSpots)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.YmsZoneId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_spot_id_fk");
            });

            modelBuilder.Entity<MWarehouse>(entity =>
            {
                entity.HasKey(e => e.WarehouseId)
                    .HasName("m_Warehouse_pk");

                entity.ToTable("m_Warehouse", "yms");

                entity.HasIndex(e => e.RowId, "m_Warehouse_uc")
                    .IsUnique();

                entity.Property(e => e.WarehouseId).HasColumnName("warehouse_id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .HasDefaultValueSql("((1))")
                    .IsFixedLength();

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId).HasColumnName("row_id");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.WarehouseDescription)
                    .HasMaxLength(100)
                    .HasColumnName("warehouse_description");

                entity.Property(e => e.WarehouseNumber)
                    .HasMaxLength(50)
                    .HasColumnName("warehouse_number");
            });

            modelBuilder.Entity<MYard>(entity =>
            {
                entity.HasKey(e => e.YardId)
                    .HasName("m_yard_pk");

                entity.ToTable("m_yard", "yms");

                entity.HasIndex(e => e.RowId, "m_yard_uc")
                    .IsUnique();

                entity.Property(e => e.YardId).HasColumnName("yard_id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.FacilityId).HasColumnName("facility_id");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YardDescription).HasColumnName("yard_description");

                entity.Property(e => e.YardName)
                    .HasMaxLength(150)
                    .HasColumnName("yard_name");

                entity.Property(e => e.YardOrganization)
                    .HasMaxLength(100)
                    .HasColumnName("yard_organization");
            });

            modelBuilder.Entity<MZone>(entity =>
            {
                entity.HasKey(e => e.ZoneId)
                    .HasName("m_zone_pk");

                entity.ToTable("m_zone", "yms");

                entity.HasIndex(e => e.RowId, "m_zone_uc")
                    .IsUnique();

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.SpotCapacity).HasColumnName("spot_capacity");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YmsYardId).HasColumnName("yms_yard_id");

                entity.Property(e => e.ZoneDescription).HasColumnName("zone_description");

                entity.Property(e => e.ZoneName)
                    .HasMaxLength(150)
                    .HasColumnName("zone_name");

                entity.Property(e => e.ZoneTypeId).HasColumnName("zone_type_id");

                entity.HasOne(d => d.YmsYard)
                    .WithMany(p => p.MZones)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.YmsYardId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_zone_id_fk");

                entity.HasOne(d => d.ZoneType)
                    .WithMany(p => p.MZones)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.ZoneTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("yms_zonetype_id_fk");
            });

            modelBuilder.Entity<MZoneType>(entity =>
            {
                entity.ToTable("m_zoneType", "yms");

                entity.HasIndex(e => e.RowId, "m_zoneType_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("active")
                    .IsFixedLength();

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.ZoneType)
                    .HasMaxLength(150)
                    .HasColumnName("zone_type");
            });

            modelBuilder.Entity<TDockDoorAppointment>(entity =>
            {
                entity.ToTable("t_DockDoorAppointment", "yms");

                entity.HasIndex(e => e.RowId, "t_DockDoorAppointment_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AppointmentId).HasColumnName("appointment_id");

                entity.Property(e => e.DockDoorId).HasColumnName("dock_door_id");

                entity.Property(e => e.FacilityId).HasColumnName("facility_id");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.WarehouseId).HasColumnName("warehouse_id");

                entity.HasOne(d => d.DockDoor)
                    .WithMany(p => p.TDockDoorAppointments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.DockDoorId)
                    .HasConstraintName("t_DockDoorAppointment_zone_fk");

                entity.HasOne(d => d.Warehouse)
                    .WithMany(p => p.TDockDoorAppointments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.WarehouseId)
                    .HasConstraintName("t_DockDoorAppointment_yard_fk");
            });

            modelBuilder.Entity<TYardAppointment>(entity =>
            {
                entity.ToTable("t_YardAppointment", "yms");

                entity.HasIndex(e => e.RowId, "t_YardAppointmenta_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AppointmentId).HasColumnName("appointment_id");

                entity.Property(e => e.FacilityId).HasColumnName("facility_id");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.SpotId).HasColumnName("spot_id");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YardId).HasColumnName("yard_id");

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");

                entity.HasOne(d => d.Yard)
                    .WithMany(p => p.TYardAppointments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.YardId)
                    .HasConstraintName("t_YardAppointment_yard_fk");

                entity.HasOne(d => d.Zone)
                    .WithMany(p => p.TYardAppointments)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.ZoneId)
                    .HasConstraintName("t_YardAppointment_zone_fk");
            });

            modelBuilder.Entity<TYardMovement>(entity =>
            {
                entity.ToTable("t_YardMovement", "yms");

                entity.HasIndex(e => e.RowId, "t_YardMovement_uc")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AmsAppointmentId).HasColumnName("ams_appointment_id");

                entity.Property(e => e.EquipmentId).HasColumnName("equipment_id");

                entity.Property(e => e.FacilityId).HasColumnName("facility_id");

                entity.Property(e => e.ModificationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("modification_date");

                entity.Property(e => e.MoveTypeId).HasColumnName("moveType_id");

                entity.Property(e => e.MovementStatus).HasColumnName("movement_status");

                entity.Property(e => e.PriorityId).HasColumnName("priority_id");

                entity.Property(e => e.RegistrationDate)
                    .HasColumnType("datetime")
                    .HasColumnName("registration_date");

                entity.Property(e => e.RejectReasonId).HasColumnName("rejectReason_id");

                entity.Property(e => e.RowId)
                    .HasColumnName("row_id")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.SpotId).HasColumnName("spot_id");

                entity.Property(e => e.UserModificationId).HasColumnName("user_modification_id");

                entity.Property(e => e.UserRegistrationId).HasColumnName("user_registration_id");

                entity.Property(e => e.YardId).HasColumnName("yard_id");

                entity.Property(e => e.ZoneId).HasColumnName("zone_id");

                entity.HasOne(d => d.Equipment)
                    .WithMany(p => p.TYardMovements)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.EquipmentId)
                    .HasConstraintName("t_YardMovement_equipment_fk");

                entity.HasOne(d => d.MoveType)
                    .WithMany(p => p.TYardMovements)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.MoveTypeId)
                    .HasConstraintName("t_YardMovement_fk");

                entity.HasOne(d => d.Yard)
                    .WithMany(p => p.TYardMovements)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.YardId)
                    .HasConstraintName("t_YardMovement_yard_fk");

                entity.HasOne(d => d.Zone)
                    .WithMany(p => p.TYardMovements)
                    .HasPrincipalKey(p => p.RowId)
                    .HasForeignKey(d => d.ZoneId)
                    .HasConstraintName("t_YardMovement_zone_fk");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
