﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Interfaces.Repositories;
using YMS.Core.Dto;

using AutoMapper;
using Microsoft.EntityFrameworkCore;
using YMS.Domain.Context;
using YMS.Domain.Entities;
using YMS.Core.Dto.ResponseDto;

namespace YMS.Infrastructure.Repositories
{
    public class YardRepository : Repository<MYard>, IYardRepository 
    {
        private yms_dbContext dbContext
        {
            get { return Context as yms_dbContext; }
        }
        public YardRepository(yms_dbContext context) : base(context)
        {

        }

        public async Task<List<PendingYardMovementResponseDto>> GetListofPendingYardMovements()
        {
            try
            {

                List<PendingYardMovementResponseDto> PendingYardMovementList = await dbContext.TYardMovements
                                                     .Select(x => new PendingYardMovementResponseDto
                                                     {
                                                         MovementId = x.RowId,
                                                         YardMovementNumber = x.Yard.YardId,
                                                         Source = string.Concat(x.Yard.YardName , " ",x.Zone.ZoneName," ", (from xTMS in dbContext.TYardMovements
                                                                                                                            join mSpot in dbContext.MSpots on xTMS.RowId equals mSpot.RowId                                                                                                
                                                                                                                            select "Spot" + mSpot.SpotNumber).FirstOrDefault()),

                                                         Destination = string.Concat(x.Yard.YardName, " ", x.Zone.ZoneName," ", (from xTMS in dbContext.TYardMovements
                                                                                                                                 join mSpot in dbContext.MSpots on xTMS.RowId equals mSpot.RowId
                                                                                                                                 select "Spot" + mSpot.SpotNumber).FirstOrDefault()),
                                                         EqupmentNumber =null,
                                                         EqupmentType=null,
                                                         Created = x.RegistrationDate,
                                                         TrailerNumber=null,
                                                         MoveType = x.MoveType.MoveType,
                                                         Periority=x.PriorityId.ToString(),
                                                     }).ToListAsync();

                return PendingYardMovementList;

            }
            catch (Exception)
            {
                throw;
            }
        }

    }

    }
