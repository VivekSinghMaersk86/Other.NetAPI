﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Interfaces.Repositories;
using YMS.Core.Interfaces.Services;
using Microsoft.Extensions.Logging;
using AutoMapper;
using YMS.Domain.Entities;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;
using Microsoft.EntityFrameworkCore;

namespace YMS.Core.Services
{
    public class YardService :IYardService
    {
        public readonly IYardRepository _yardRepository;
        public readonly IYardAppointmentRepository _yardAppointmentRepository;
        private readonly ILogger<YardService> _logger;
        private readonly IMapper _mapper;
        public YardService(IYardRepository yardRepository, IYardAppointmentRepository yardAppointmentRepository, ILogger<YardService> logger, IMapper mapper)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _yardRepository = yardRepository ?? throw new ArgumentNullException(nameof(yardRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(_mapper));
            _yardAppointmentRepository = yardAppointmentRepository ?? throw new ArgumentNullException(nameof(yardAppointmentRepository));
        }
        public async Task<CreateEntitytResponseDto> CreateYard(CreateYardRequestDto yardRequestDto)
        {
            _logger.LogInformation("Service Method : YardService/CreateYard - Start");
            CreateEntitytResponseDto yardResponseDto = new CreateEntitytResponseDto();
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                var query = await _yardRepository.FindAsync(a => EF.Functions.Like(a.YardName, yardRequestDto.YardName));
                if (!query.Any())
                {
                    var yard = _mapper.Map<CreateYardRequestDto, MYard>(yardRequestDto);
                    var yardEntity = await _yardRepository.AddAsync(yard);
                    responseStatus.statusMessage = "Yard added";
                    yardResponseDto.responseStatus = responseStatus;
                    yardResponseDto.Rowid = yardEntity.RowId;
                }
                else
                {
                    responseStatus.statusMessage = "Yard already exist";
                    yardResponseDto.responseStatus = responseStatus;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/CreateYard Error - " + ex);
                throw;
            }
            return yardResponseDto;
        }

        public async Task<ResponseStatus> DeleteYard(Guid yardId)
        {
            _logger.LogInformation("Service Method : YardService/DeleteYard - Start");
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                var entity = await _yardRepository.SingleOrDefaultAsync(x => x.RowId == yardId && x.Active == "1");
                entity.Active = "0";
                entity.ModificationDate = DateTime.UtcNow;
                _yardRepository.Update(entity);
                responseStatus.statusMessage = "Yard deleted";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/DeleteYard Error - " + ex);
                throw;
            }
            return responseStatus;
        }

        public async Task<ResponseStatus> UpdateYard(UpdateYardRequestDto yardRequestDto)
        {
            _logger.LogInformation("Service Method : YardService/UpdateYard - Start");
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                var query = await _yardRepository.FindAsync(a => a.YardName.Equals(yardRequestDto.YardName) && a.RowId == yardRequestDto.RowId && a.Active == "1");
                if (query.Any())
                {
                    var entity = query.FirstOrDefault();
                    var yardmap = _mapper.Map<UpdateYardRequestDto, MYard>(yardRequestDto, entity);
                    _yardRepository.Update(yardmap);
                    responseStatus.statusMessage = "Yard updated";
                }
                else
                {
                    responseStatus.statusMessage = "Yard does not exist or is not active";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/UpdateYard Error - " + ex);
                throw;
            }
            return responseStatus;
        }
        public async Task<ResponseStatus> UpdateAssignedYard(UpdateAssignedYardRequestDto yardRequestDto)
        {
            _logger.LogInformation("Service Method : YardService/UpdateAssignedYard - Start");
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                var entity = await _yardAppointmentRepository.FindAsync(a => a.AppointmentId == yardRequestDto.AppointmentId);
                if (entity.Any())
                {
                    var appointment = entity.FirstOrDefault();
                    var assignedYard = _mapper.Map<UpdateAssignedYardRequestDto, TYardAppointment>(yardRequestDto, appointment);
                    _yardAppointmentRepository.Update(assignedYard);
                    responseStatus.statusMessage = "Assigned yard location updated";
                }
                else
                {
                    var appointment = entity.FirstOrDefault();
                    var assignedYard = _mapper.Map<UpdateAssignedYardRequestDto, TYardAppointment>(yardRequestDto, appointment);
                    await _yardAppointmentRepository.AddAsync(assignedYard);
                    responseStatus.statusMessage = "Assigned yard location added ";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/UpdateAssignedYard Error - " + ex);
                throw;
            }
            return responseStatus;
        }

        public async Task<IEnumerable<AvailableYardsResponseDto>> GetAvailableYards()
        {
            _logger.LogInformation("Service Method : YardService/GetAvailableYards - Start");
            IEnumerable<AvailableYardsResponseDto> availableYards = Enumerable.Empty<AvailableYardsResponseDto>();
            try
            {
                var entity = await _yardRepository.FindAsync(x => x.Active == "1");

                availableYards = _mapper.Map<IEnumerable<AvailableYardsResponseDto>>(entity);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/GetAvailableYards Error - " + ex);
                throw;
            }
            return availableYards;
        }

        public async Task<IEnumerable<PendingYardMovementResponseDto>> GetListofPendingYardMovements()
        {
            _logger.LogInformation("Service Method : YardService/GetListofPendingYardMovements - Start");

            List<PendingYardMovementResponseDto> PendingYardLists = new List<PendingYardMovementResponseDto>();
            try
            {
                PendingYardLists = await _yardRepository.GetListofPendingYardMovements();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardService/GetListofPendingYardMovements Error - " + ex);
                throw;
            }
            return PendingYardLists; 
        }
    }
}
