﻿using System;
using System.Collections.Generic;

namespace YMS.Domain.Entities 
{
    public partial class TYardMovement
    {
        public TYardMovement()
        {
            TYardMovementStatuses = new HashSet<TYardMovementStatus>();
        }

        public int Id { get; set; }
        public Guid RowId { get; set; }
        public string YardMoveNumber { get; set; } = null!;
        public Guid? AmsAppointmentId { get; set; }
        public Guid FacilityId { get; set; }
        public Guid? YardId { get; set; }
        public Guid? ZoneId { get; set; }
        public Guid? SpotId { get; set; }
        public Guid? EquipmentId { get; set; }
        public Guid? MoveTypeId { get; set; }
        public int? PriorityId { get; set; }
        public DateTime? MoveCompletedTime { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? ModificationDate { get; set; }
        public Guid? UserRegistrationId { get; set; }
        public Guid? UserModificationId { get; set; }
        public int? MovementStatus { get; set; }
        public Guid? RejectReasonId { get; set; }

        public virtual MEquipment? Equipment { get; set; }
        public virtual MMoveType? MoveType { get; set; }
        public virtual MYard? Yard { get; set; }
        public virtual MZone? Zone { get; set; }
        public virtual ICollection<TYardMovementStatus> TYardMovementStatuses { get; set; }

    }
}
