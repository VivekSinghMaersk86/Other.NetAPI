﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Domain.Entities;

namespace YMS.Core.Interfaces.Repositories
{
    public interface IYardMoveRepository : IRepository<TYardMovement>
    {
  
    }
}

