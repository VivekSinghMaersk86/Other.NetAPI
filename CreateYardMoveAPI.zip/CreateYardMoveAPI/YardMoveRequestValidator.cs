﻿using FluentValidation;
using YMS.Core.Dto.RequestDto;

namespace YMS.API.Validators
{
    public class YardMoveRequestValidator : AbstractValidator<YardMoveRequestDto>
    {
        public YardMoveRequestValidator()
        {
            RuleFor(m => m.YardId).NotEmpty().WithMessage("Yard Id is Mandatory");
            RuleFor(m => m.SpotId).NotEmpty().WithMessage("Spot Id is Mandatory");
            RuleFor(m => m.ZoneId).NotEmpty().WithMessage("Zone Id is Mandatory");
        }
    }
}
