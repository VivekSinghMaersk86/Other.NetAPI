﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;
using YMS.Core.Interfaces;
using YMS.Core.Interfaces.Repositories;
using YMS.Core.Interfaces.Services;
using YMS.Domain.Entities;

namespace YMS.Core.Services
{
    public class YardMoveService : IYardMoveService
    {
         public readonly IYardMoveRepository _yardMoveRepository;
         public readonly ILogger<YardMoveService> _logger;
         private readonly IMapper _mapper;

        public YardMoveService(IYardMoveRepository yardMoveRepository, ILogger<YardMoveService> logger, IMapper mapper)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _yardMoveRepository = yardMoveRepository ?? throw new ArgumentNullException(nameof(yardMoveRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(_mapper));
        }

        public async Task<CreateEntitytResponseDto> CreateYardMove(YardMoveRequestDto yardMoveRequestDto)
        {
            _logger.LogInformation("Service Method : YardMoveService/CreateYardMove - Start");
            ResponseStatus responseStatus = new ResponseStatus();
            CreateEntitytResponseDto yardMoveResponseDto = new CreateEntitytResponseDto();
            try
            {
                var query = await _yardMoveRepository.FindAsync(a => a.AmsAppointmentId.Equals(yardMoveRequestDto.AppointmentId));
                if (!query.Any())
                {
                    var yardMovement = _mapper.Map<YardMoveRequestDto, TYardMovement>(yardMoveRequestDto);
                    var entity = await _yardMoveRepository.AddAsync(yardMovement);
                    responseStatus.statusMessage = "YardMovement added";
                    yardMoveResponseDto.responseStatus = responseStatus;
                    yardMoveResponseDto.Rowid = entity.RowId;
                }
                else
                {
                    responseStatus.statusMessage = "YardMovement already exist";
                    yardMoveResponseDto.responseStatus = responseStatus;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Service Method : YardMoveService/CreateYardMove Error - " + ex);
                throw;
            }
            return yardMoveResponseDto;
        }
    }
}
