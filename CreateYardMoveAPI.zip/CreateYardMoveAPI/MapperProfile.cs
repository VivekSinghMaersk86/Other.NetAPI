﻿using AutoMapper;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;
using YMS.Domain.Entities;
using static YMS.Core.Helper.Constants;

namespace YMS.Core.Mapper
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            CreateMap<CreateWarehouseRequestDto, MWarehouse>()
                .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))
                .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
                .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
                .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
                .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<CreateDockdoorRequestDto, MDockdoor>()
                 .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))
                .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
                .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
                .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
                .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<CreateYardRequestDto, MYard>()
                .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))
               .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<UpdateYardRequestDto, MYard>()
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow)).IgnoreAllNonExisting();


            CreateMap<CreateEqpRequestDto, MEquipment>()
               .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))
              .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
              .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
              .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
              .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<UpdateEqpRequestDto, MEquipment>()
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow)).IgnoreAllNonExisting();

            CreateMap<MEquipmentCategory, EquipmentCategoryResponseDto>()
               .ForPath(dest => dest.EqpCategoryId, opt => opt.MapFrom(src => src.RowId));

            CreateMap<CreateZoneRequestDto, MZone>()
                .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))
               .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<UpdateZoneRequestDto, MZone>()
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow)).IgnoreAllNonExisting();

            CreateMap<CreateSpotRequestDto, MSpot>()
                .ForPath(dest => dest.Active, opt => opt.MapFrom(src => '1'))

               .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));


            CreateMap<MCategoryType, CategoryTypeResponseDto>()
              .ForPath(dest => dest.CategoryTypeId, opt => opt.MapFrom(src => src.RowId));

            CreateMap<MEquipmentStatus, EquipmentStatusResponseDto>()
             .ForPath(dest => dest.EqpStatusId, opt => opt.MapFrom(src => src.RowId));


            CreateMap<MZoneType, ZoneTypeRequestDto>()
               .ForPath(dest => dest.ZoneTypeID, opt => opt.MapFrom(src => src.RowId));

            CreateMap<MEquipment, YardEqpListResponseDto>()
               .ForPath(dest => dest.EquipmentId, opt => opt.MapFrom(src => src.RowId));

            CreateMap<MEquipment, AvailableYardEqpListResponseDto>()
            .ForPath(dest => dest.EquipmentId, opt => opt.MapFrom(src => src.RowId));


            CreateMap<MMoveType, MoveTypeResponseDto>()
               .ForPath(dest => dest.TypeId, opt => opt.MapFrom(src => src.RowId))
               .ForPath(dest => dest.TypeName, opt => opt.MapFrom(src => src.MoveType));

            CreateMap<UpdateAssignedDockRequestDto, TDockDoorAppointment>()
            .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<UpdateAssignedYardRequestDto, TYardAppointment>()
             .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
              .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
              .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
              .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

             CreateMap<CreateYardMoveRequestDto, TYardMovement>()
               .ForPath(dest => dest.RowId, opt => opt.MapFrom(src => Guid.NewGuid()))
               .ForPath(dest => dest.AmsAppointmentId, opt => opt.MapFrom(src => src.AppointmentId))
               .ForPath(dest => dest.MovementStatus, opt => opt.MapFrom(src => (int)Enum.Parse(typeof(MovementStatus), src.MovementStatus)))
               .ForPath(dest => dest.PriorityId, opt => opt.MapFrom(src => (int)Enum.Parse(typeof(Priority), src.Priority)))
               .ForPath(dest => dest.UserRegistrationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.UserModificationId, opt => opt.MapFrom(src => src.UserId))
               .ForPath(dest => dest.RegistrationDate, opt => opt.MapFrom(src => DateTime.UtcNow))
               .ForPath(dest => dest.ModificationDate, opt => opt.MapFrom(src => DateTime.UtcNow));

            CreateMap<MYard, AvailableYardsResponseDto>()
              .ForPath(dest => dest.YardID, opt => opt.MapFrom(src => src.RowId));

            CreateMap<MWarehouse, AvailableWarehouseResponseDto>()
              .ForPath(dest => dest.WarehouseId, opt => opt.MapFrom(src => src.RowId));

            CreateMap<YardMoveRequestDto, TYardMovement>()
                .ForPath(dest => dest.RowId, opt => opt.MapFrom(src => src.UserId))
                .ForPath(dest => dest.AmsAppointmentId, opt => opt.MapFrom(src => src.AppointmentId))
                //if(dest => dest.IsCompleted == 1)
                .ForPath(dest => dest.YardMoveNumber, opt => opt.MapFrom(src => src.YardMoveNumber));

        }
    }
}
 