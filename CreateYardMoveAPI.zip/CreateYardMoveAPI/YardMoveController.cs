﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using YMS.API.Validators;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;
using YMS.Core.Interfaces.Services;
using YMS.Core.Services;

namespace YMS.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class YardMoveController : ControllerBase
    {
        private readonly IYardMoveService _yardMoveService;
        private readonly ILogger<YardMoveController> _logger;
        public YardMoveController(IYardMoveService yardMoveService, ILogger<YardMoveController> logger)
        {
            _yardMoveService = yardMoveService ?? throw new ArgumentNullException(nameof(yardMoveService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpPost]
        [Route("CreateYardMove")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public async Task<IActionResult> CreateYardMove(YardMoveRequestDto yardMoveRequestDto)
        {
            ResponseStatus responseStatus = new ResponseStatus();
            try
            {
                _logger.LogInformation("Start - CreateYardMove");
                var validator = new YardMoveRequestValidator();
                var validationResult = validator.Validate(yardMoveRequestDto);
                if (validationResult.IsValid)
                {
                    var result = await _yardMoveService.CreateYardMove(yardMoveRequestDto);
                    return Ok(result);
                }
                else
                    return BadRequest(validationResult.Errors);
            }
            catch (Exception ex)
            {
                _logger.LogError("CreateYardMove Error : " + ex);
                responseStatus.statusMessage = ex.Message;
                responseStatus.statusCode = (int)HttpStatusCode.InternalServerError;
                return BadRequest(responseStatus);
            }
        }


    }
}
