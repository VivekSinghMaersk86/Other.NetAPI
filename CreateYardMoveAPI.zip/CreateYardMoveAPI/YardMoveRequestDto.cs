﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YMS.Core.Dto.RequestDto
{
    public class YardMoveRequestDto
    {
        public Guid AppointmentId { get; set; }
        public Guid FacilityId { get; set; }
        public Guid YardId { get; set; }
        public Guid ZoneId { get; set; }
        public Guid SpotId { get; set; }
        public Guid EquipmentId { get; set; }
        public Guid MoveTypeId { get; set; }
        public string PriorityId { get; set; }
        public string MovementStatus { get; set; }

        public string YardMoveNumber { get; set; }

        public Guid UserId { get; set; }
    }
}
