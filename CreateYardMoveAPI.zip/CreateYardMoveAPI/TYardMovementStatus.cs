﻿using System;
using System;
using System.Collections.Generic;

namespace YMS.Domain.Entities
{
    public partial class TYardMovementStatus
    {
        public int Id { get; set; }
        public Guid RowId { get; set; }
        public Guid? MovementId { get; set; }
        public int? MovementStatus { get; set; }
        public DateTime? ActivityTime { get; set; }
        public Guid? RejectReasonId { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? ModificationDate { get; set; }
        public Guid? UserRegistrationId { get; set; }
        public Guid? UserModificationId { get; set; }

        public virtual TYardMovement? Movement { get; set; }
    }
}
