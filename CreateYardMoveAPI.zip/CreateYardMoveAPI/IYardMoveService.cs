﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YMS.Core.Dto.RequestDto;
using YMS.Core.Dto.ResponseDto;

namespace YMS.Core.Interfaces.Services
{
    public interface IYardMoveService
    {
    Task<CreateEntitytResponseDto> CreateYardMove(YardMoveRequestDto yardMoveRequestDto);

    }

}
