﻿using YMS.Core.Interfaces.Repositories;
using YMS.Core.Interfaces.Services;
using YMS.Core.Services;
using YMS.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using YMS.Domain.Context;
using YMS.Infrastructure.ConnectedServices;
using YMS.Core.Interfaces;

namespace YMS.API
{
    public static class DependencyInjection
    {
        public static IServiceCollection ConfigureDependencyInjection(this IServiceCollection services, IConfiguration configuration)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }
            if (configuration == null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }
            string amsURL = Environment.GetEnvironmentVariable("AMSURL");
            string connectionstring = Environment.GetEnvironmentVariable("ConnectionString");
            services.AddDbContext<yms_dbContext>(options => options.UseSqlServer(connectionstring));
            services.AddScoped<IWarehouseRepository, WarehouseRepository>();
            services.AddScoped<IWarehouseService, WarehouseService>();

            services.AddScoped<IDockdoorRepository, DockdoorRepository>();
            services.AddScoped<IDockdoorService, DockdoorService>();

            services.AddScoped<IYardRepository, YardRepository>(); 
            services.AddScoped<IYardService, YardService>();

            services.AddScoped<IYardMoveService, YardMoveService>();
            services.AddScoped<IYardMoveRepository, YardMoveRepository>();

            services.AddScoped<IZoneRepository, ZoneRepository>();
            services.AddScoped<ISpotRepository, SpotRepository>();
            services.AddScoped<IZoneTypeRepository, ZoneTypeRepository>();
            services.AddScoped<IZoneService, ZoneService>();


            services.AddScoped<IEquipmentRepository, EquipmentRepository>();
            services.AddScoped<IEquipmentCategoryRepository, EquipmentCategoryRepository>();
            services.AddScoped<IEqupmentStatusRepository, EqupmentStatusRepository>();
            services.AddScoped<ICategoryTypeRepository, CategoryTypeRepository>();
            services.AddScoped<IEquipmentService, EquipmentService>();

        

            services.AddScoped<IEquipmentListRepository, YardEquipmentListRepository>();
            services.AddScoped<IEquipmentListService, YardEquipmentListService>();
            services.AddScoped<IDockDoorAppointmentRepository,DockDoorAppointmentRepository>();
            services.AddScoped<IYardAppointmentRepository, YardAppointmentRepository>();

            services.AddScoped<IMovetypeRepository, MovetypeRepository>();
            services.AddScoped<IYardMovementRepository, YardMovementRepository>();
            services.AddScoped<IMovementRepository, MovementRepository>();
            services.AddScoped<IMovementService, MovementService>();
            services.AddTransient<IAppointmentService, AppointmentService>();
            services.AddSingleton<IAMSClient, AMSClient>(serviceProvider =>
            {
                return new AMSClient(amsURL, new HttpClient());
            });

            return services;
        }
    }
}
